.. building-block-rq1 documentation master file, created by
   sphinx-quickstart on Wed May 22 13:36:37 2024.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to building-block-rq1's documentation!
==============================================

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   Getting_started
   Query
   Examples
   Known_issues
   Developer_guide
   References



Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
