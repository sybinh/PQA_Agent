# building-block-rq1

## Table of Contents
- [Overview](#overview)
- [Prerequisites](#prerequisites)
- [Installation](#installation)
- [User Manual](#user-manual)
- [Features](#features)
- [Known Issues](#known-issues)
- [Contribution](#contribution)
- [For Developers](#for-developers)
- [Getting Help](#getting-help)
- [License](#license)

## Overview
building-block-rq1 is a Python library for RQ1. Its purpose is to make it easy for creating automation solution related to RQ1 system.

If you find this library helpful, consider adding a star on [github repository](https://github.boschdevcloud.com/bios-automation-marketplace/building-block-rq1) and
[Automation Marketplace](https://rb-wam-ap.bosch.com/automation-marketplace/solution/969bfe52-5232-4693-804d-ad6c2bcdb5da). You can also subsribe to get new
release notification.

This project is running on company's sponsor and we need the number to show it's a good investment. That's why please spend 5 minutes to complete this survey: https://forms.office.com/e/BBsVcuhhpp

## Installation
###  Prerequisites
- python >= 3.9
- [Configure pip index url](https://inside-docupedia.bosch.com/confluence/x/qUlg9w)

```bash
pip install building-block-rq1
```

**Note**: If that does not work, you can install the library directly from github:
```bash
pip install git+https://github.boschdevcloud.com/bios-automation-marketplace/building-block-rq1.git
```

## User Manual
Official documentation: https://pages.github.boschdevcloud.com/bios-automation-marketplace/building-block-rq1/

### Examples:
#### Get
```python
import os
from rq1 import BaseUrl, Client
from rich import print  # pretty print
from rq1.models import Workitem, Issue, IssueProperty

RQ1_USER = os.environ["RQ1_USER"]
RQ1_PASSWORD = os.environ["RQ1_PASSWORD"]
RQ1_TOOLNAME = os.environ["RQ1_TOOLNAME"]
RQ1_TOOLVERSION = os.environ["RQ1_TOOLVERSION"]

client = Client(
    base_url=BaseUrl.ACCEPTANCE,
    username=RQ1_USER,
    password=RQ1_PASSWORD,
    toolname=RQ1_TOOLNAME,
    toolversion=RQ1_TOOLVERSION,
)


def example_1():
    wi = client.get_record_by_uri(
        Workitem,
        "https://rb-dgsrq1-oslc-q.de.bosch.com/cqweb/oslc/repo/RQ1_ACCEPTANCE/db/RQONE/record/16777232-37320999",
    )
    print(wi)


def example_2():
    # This will get all properties of the issue, but it will take some time
    issue = client.get_record_by_rq1_number(Issue, "RQONE03765304")
    print(issue)

    # Select only the properties that you need, this will be faster
    issue = client.get_record_by_rq1_number(
        Issue, "RQONE03765304", select=[IssueProperty.accountnumbers]
    )
    print(issue)


if __name__ == "__main__":
    example_1()
    example_2()
```

#### Query
```python
from datetime import datetime
import os
from rq1 import BaseUrl, Client
from rq1.models import Issue, IssueProperty, Workitem, Project, ProjectProperty, Users, UsersProperty
from rq1.base import reference
from rich import print  # pretty print

RQ1_USER = os.environ["RQ1_USER"]
RQ1_PASSWORD = os.environ["RQ1_PASSWORD"]
RQ1_TOOLNAME = os.environ["RQ1_TOOLNAME"]
RQ1_TOOLVERSION = os.environ["RQ1_TOOLVERSION"]

client = Client(
    base_url=BaseUrl.ACCEPTANCE,
    username=RQ1_USER,
    password=RQ1_PASSWORD,
    toolname=RQ1_TOOLNAME,
    toolversion=RQ1_TOOLVERSION,
)


def example_1():
    # query all workitems in the database
    # select="*": take all properties
    # paging=True, page_size=5: use paging, each page has 5 members
    query = client.query(Workitem, select="*", paging=True, page_size=5)

    # check that only 5 workitems are returned in the first page
    assert len(query.members) == 5

    # here is the total workitems
    print(query.total_count)

    # you can get the next page with
    next_page = client.get_next_query_page(query)
    assert next_page is not None
    assert len(next_page.members) == 5

    # you can get a page at any index with
    # start_index=13 is not page index, but member index.
    # So, the line below should return members from index 13 to 17 since we have 5 members per page
    random_page = client.get_query_page(query, start_index=13)
    assert random_page is not None
    assert len(random_page.members) == 5


def example_2():
    # let's try a more complex query
    # first, we get the uri of project RQONE00002140
    query = client.query(
        Project,
        where=ProjectProperty.id == "RQONE00002140",
        select=[
            ProjectProperty.dcterms__title,
            ProjectProperty.status,
        ],  # only take title and status of the project
    )
    assert query.total_count == 1
    project = query.members[0]
    assert (
        project.dcterms__title is not None
        and "IoExtDev - IO External Devices" in project.dcterms__title
    )
    assert project.status == "Active"

    # then get uri of some users
    query = client.query(Users, where=UsersProperty.login_name == "NTO7HC")
    user1 = query.members[0]
    query = client.query(Users, where=UsersProperty.login_name == "VDO8HC")
    user2 = query.members[0]

    clause_1 = IssueProperty.belongstoproject == reference(project.uri)
    clause_2 = IssueProperty.submitdate > datetime(2020, 1, 1)
    clause_3 = IssueProperty.assignee.is_one_of(
        [reference(user1.uri), reference(user2.uri)]
    )
    query = client.query(
        Issue, where=clause_1 & clause_2 & clause_3, paging=True, page_size=5
    )
    print(query)


def example_3():
    # You can also use a predefined query from RQ1 web app
    query = client.run_query(Workitem, query_id=192940459, select="*", page_size=10)
    print(query)


if __name__ == "__main__":
    example_1()
    example_2()
    example_3()
```
#### More examples
See the [examples](./examples/) folder.

### Async Client Usage

The library also provides an `AsyncClient` for asynchronous operations, which can significantly improve performance when making multiple concurrent requests to the RQ1 system.

#### Basic Async Usage
```python
import asyncio
import os
from rq1 import BaseUrl, AsyncClient
from rq1.models import Issue

async def main():
    async with AsyncClient(
        base_url=BaseUrl.ACCEPTANCE,
        username=os.environ["RQ1_USER"],
        password=os.environ["RQ1_PASSWORD"],
        toolname=os.environ["RQ1_TOOLNAME"],
        toolversion=os.environ["RQ1_TOOLVERSION"],
    ) as client:
        
        # All the same methods as Client, but with async/await
        issue = await client.get_record_by_rq1_number(Issue, "RQONE03765304")
        print(issue)
        
        # Query asynchronously
        query_result = await client.query(
            Issue,
            where='cq:state="Open"',
            select="*",
            page_size=10
        )
        print(f"Found {query_result.total_count} open issues")

if __name__ == "__main__":
    asyncio.run(main())
```

#### Concurrent Operations
```python
import asyncio
from rq1 import BaseUrl, AsyncClient
from rq1.models import Issue

async def concurrent_example():
    async with AsyncClient(
        base_url=BaseUrl.ACCEPTANCE,
        username=os.environ["RQ1_USER"],
        password=os.environ["RQ1_PASSWORD"],
        toolname=os.environ["RQ1_TOOLNAME"],
        toolversion=os.environ["RQ1_TOOLVERSION"],
    ) as client:
        
        # Run multiple queries concurrently
        tasks = [
            client.query(Issue, where='cq:state="Open"', page_size=1),
            client.query(Issue, where='cq:state="Closed"', page_size=1),
            client.query(Issue, where='cq:state="InProgress"', page_size=1),
        ]
        
        results = await asyncio.gather(*tasks)
        
        for i, result in enumerate(results):
            state = ["Open", "Closed", "InProgress"][i]
            print(f"{state} issues: {result.total_count}")

if __name__ == "__main__":
    asyncio.run(concurrent_example())
```

#### Key Differences from Synchronous Client

1. **Context Manager**: AsyncClient must be used as an async context manager (`async with`)
2. **Async Methods**: All methods are async and must be awaited
3. **Concurrency**: Multiple operations can be run concurrently using `asyncio.gather()`
4. **Performance**: Better performance for I/O-bound operations, especially when making multiple requests
5. **Dependencies**: Requires `aiohttp` (automatically installed as a dependency)

## Features
Support query/read/update/create for all record types:
- Attachmentmapping
- Attachments
- Background
- Commercial
- Commercialacl
- Contact
- Email_Rule
- Exchangeconfig
- Exchangeprotocol
- Externallink
- Groups
- History
- Historylog
- Issue
- Issueissuemap
- Issuereleasemap
- Mapping
- Problem
- Project
- Ratl_Replicas
- Release
- Releasereleasemap
- Rq1_Configuration
- Rq1_Instructiontype
- Rq1_Logging
- Rq1_Metadata
- Rq1_Rolespermission
- Rq1_Roleuser
- Rq1_Rulesconfig
- Rq1_Tldselector
- Rq1_Webtoolconfig
- Users
- Workitem

Support downloading and uploading attachments.

## Contribution
See [Contribution guidelines](https://inside-docupedia.bosch.com/confluence/x/2A-0AgE)

## For Developers
See [Developer guide](https://pages.github.boschdevcloud.com/bios-automation-marketplace/building-block-rq1/Developer_guide.html)

## Getting help
* __Author:__ Nguyen Duc Toan (MS/EEU21-PS) 
* __Author email:__ nto7hc@bosch.com 

## License
BIOSL v4 -- Bosch Internal Open Source License Version 4
